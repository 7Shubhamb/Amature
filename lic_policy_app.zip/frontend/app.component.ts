import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  policies: any[] = [];

  constructor(private http: HttpClient) {
    this.loadPolicies();
  }

  loadPolicies() {
    this.http.get<any[]>('http://localhost:3000/policies').subscribe(data => {
      this.policies = data;
    });
  }

  sendReminder(policy: any) {
    const message = `LIC Policy Reminder: Policy No: ${policy.policy_number}, Due Date: ${policy.due_date}. Please ensure timely payment.`;
    window.location.href = `sms:?body=${encodeURIComponent(message)}`;
  }
}
