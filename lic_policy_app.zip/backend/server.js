const express = require('express');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const { Pool } = require('pg');
const bcrypt = require('bcrypt');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json());

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: { rejectUnauthorized: false },
});

const SECRET_KEY = process.env.SECRET_KEY;

// Admin Login
app.post('/login', async (req, res) => {
  const { email, password } = req.body;
  const result = await pool.query('SELECT * FROM admins WHERE email = $1', [email]);

  if (result.rows.length > 0) {
    const admin = result.rows[0];
    const validPassword = await bcrypt.compare(password, admin.password);

    if (validPassword) {
      const token = jwt.sign({ adminId: admin.id }, SECRET_KEY, { expiresIn: '1h' });
      return res.json({ token });
    }
  }
  res.status(401).json({ message: 'Invalid credentials' });
});

// Add LIC Policy (Admin Only)
app.post('/policies', async (req, res) => {
  const { policyNumber, dueDate } = req.body;
  await pool.query('INSERT INTO policies (policy_number, due_date) VALUES ($1, $2)', [policyNumber, dueDate]);
  res.status(201).json({ message: 'Policy added successfully' });
});

// Fetch Policies
app.get('/policies', async (req, res) => {
  const result = await pool.query('SELECT * FROM policies');
  res.json(result.rows);
});

app.listen(3000, () => console.log('Server running on port 3000'));
